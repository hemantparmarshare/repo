/**
 * 
 */
package com.ap.xsd.message.iso20022.rfpbatchinput;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;


public class XMLMarshaller {
//	private static final Logger LOGGER = Logger.getLogger(XMLMarshaller.class);

	private static JAXBContext context;

	public static final ThreadLocal<Marshaller> threadLocalMarshaller = new ThreadLocal<Marshaller>();

	public static boolean init() {
		boolean ret = true;
		try {
			context = JAXBContext.newInstance(RFPBatchFile.class);
		} catch (JAXBException ex) {
			//LOGGER.error("Error while creating JAXB context", ex);
			ret = false;
		}
		return ret;
	}

	public static String getXML(final RFPBatchFile rpfBatchFile) throws JAXBException {

		Marshaller marshaller = threadLocalMarshaller.get();

		if (marshaller == null) {
			marshaller = context.createMarshaller();

			threadLocalMarshaller.set(marshaller);
		}
System.out.println("hii");
		StringWriter sw = new StringWriter();
		 marshaller.marshal(rpfBatchFile, System.out);
		marshaller.marshal(rpfBatchFile, sw);
		String string = sw.toString();
		
		try {
			marshaller.marshal(rpfBatchFile, new FileOutputStream("question.xml"));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}  
		try {
			sw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return string;
	}
}
