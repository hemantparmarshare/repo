package com.ap.xsd.message.iso20022.rfpbatchinput;


import java.io.FileOutputStream;
import java.io.Serializable;
import java.util.ArrayList;  
  
import javax.xml.bind.JAXBContext;  
import javax.xml.bind.Marshaller;  
import com.ap.xsd.message.iso20022.rfpbatchinput.*;
  
  
public class ObjectToXml implements Serializable  {  
public static void main(String[] args) throws Exception{  
    //JAXBContext contextObj = JAXBContext.newInstance(iso.std.iso._20022.tech.xsd.head_001_001.ObjectFactory.class);  
    
	
	//String packageName=ObjectToXml.class.getPackage().getPackages().getClass();
//	ClassLoader cl=ObjectFactory.class.getClassLoader();
//	
    JAXBContext contextObj = JAXBContext.newInstance(RFPBatchFile.class);
	
	//JAXBContext contextObj = JAXBContext.newInstance("com.ap.xsd.message.iso20022.rfpbatchinput:iso.std.iso._20022.tech.xs.rain_001_001:iso.std.iso._20022.tech.xs.rain_002_001:iso.std.iso._20022.tech.xsd.head_001_001");
  
	
	
	
    Marshaller marshallerObj = contextObj.createMarshaller();  
    marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);  
    
   // marshallerObj.set
//    marshallerObj.setProperty("com.sun.xml.bind.namespacePrefixMapper",new MyNamespaceMapper()
//    		
//    {
//        @Override
//       public String getPreferredPrefix(String arg0, String arg1, boolean arg2) {
//           return "ns1";
//       }
//   });
    	//	);
    
  //  public String getPreferredPrefix(String arg0, String arg1, boolean arg2) {
   //     return "ns1";
   // }
    
    //marshallerObj.
   // marshallerObj.setProperty(Marshaller.);  


  
   // Answer ans1=new Answer(101,"java is a programming language","ravi","AKSHAY22");  
    
    //HeaderDetails HRD =new HeaderDetails();
    
    //HRD.setFileTp("TestFileTP");
    
    ObjectFactory obj =new ObjectFactory ();
    
    obj.createHeaderDetails().setFileTp("TestFiletype");
   // obj.createLogicalHeaderDetails().setLogclFileRef("TestRTLR013rra");
    
    
   // Answer ans2=new Answer(102,"java is a platform","john");  
      
   // ArrayList<Answer> list=new ArrayList<Answer>();  
   // list.add(ans1);  
   // list.add(ans2);  
      
    //RFPBatchFile que=new RFPBatchFile(HRD);  
    marshallerObj.marshal(obj, new FileOutputStream("question.xml"));  
       
}  

}  
