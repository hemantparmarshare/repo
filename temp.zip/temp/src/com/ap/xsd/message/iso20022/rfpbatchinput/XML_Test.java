package com.ap.xsd.message.iso20022.rfpbatchinput;



import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
//import java.sql.Date;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.xml.util.Answer;

import java.util.GregorianCalendar;


//import org.apache.log4j.Logger;

//import biz.neustar.gdi.model.WorkItemMesg;

/**
 * @author desingh
 * 
 */
public class XML_Test {
	//private static final Logger LOGGER = Logger.getLogger(XMLMarshaller.class);

	private static JAXBContext context;

	public static final ThreadLocal<Marshaller> threadLocalMarshaller = new ThreadLocal<Marshaller>();

	public boolean init() {
		boolean ret = true;
		try {
			context = JAXBContext.newInstance(RFPBatchFile.class);
		} catch (JAXBException ex) {
		//	LOGGER.error("Error while creating JAXB context", ex);
			ret = false;
		}
		return ret;
	}

	public  String getXML(final RFPBatchFile workItemMesg) throws JAXBException {

		Marshaller marshaller = threadLocalMarshaller.get();

		if (marshaller == null) {
			marshaller = context.createMarshaller();

			threadLocalMarshaller.set(marshaller);
		}

		StringWriter sw = new StringWriter();
		// marshaller.marshal(person, System.out);
		marshaller.marshal(workItemMesg, sw);
		return sw.toString();
	}
	
	
	public static void main(String args[]) throws JAXBException, DatatypeConfigurationException
	{
		XML_Test xmlTest= new XML_Test();
		xmlTest.init();
		
		RFPBatchFile wmg = new RFPBatchFile();
		
		PartyDetails pd = new PartyDetails();
		pd.setId("Zapp");
		pd.setTp(PartyTypeCode.SCHM);
		
		PartyDetails Spd = new PartyDetails();
		Spd.setId("000014");
		Spd.setTp(PartyTypeCode.DSTR);
		
		PartyDetails acqr = new PartyDetails();
		acqr.setId ("009368");
		acqr.setTp(PartyTypeCode.DSTR);
		
		PartyDetails Issr = new PartyDetails();
		acqr.setId ("012352");
		acqr.setTp(PartyTypeCode.FINI);

		PartyDetails RcptPty = new PartyDetails();
		RcptPty.setId ("Zapp");
		RcptPty.setTp(PartyTypeCode.SCHM);
		
	


		
		GregorianCalendar gcal = new GregorianCalendar();
		
		//java.util.Date tempDate = gcal.toGregorianCalendar().getTime();

	      // Date today = new Date();
	       GregorianCalendar c = new GregorianCalendar();
	       c.setTime(new Date());
	       XMLGregorianCalendar xmldate =DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
	       Date date=xmldate.toGregorianCalendar().getTime();
	       



		
		
		
		HeaderDetails hdmg = new HeaderDetails();
		hdmg.setFileRef("RTLR013rra");
		hdmg.setFileTp("RFPInputFromDistributor");
		hdmg.setRcptPty(pd);
		hdmg.setRcptPty(pd);
		hdmg.setSndgPty(Spd);
		hdmg.setSndgPty(Spd);
		hdmg.setFileBusDt(xmldate);
		
	
		
		
		LogicalHeaderDetails logicDetail =new LogicalHeaderDetails();
		logicDetail.setLogclFileRef("RTLR013rra");
		logicDetail.setMsgTp("RTLRespFromDist");
		logicDetail.setSndgPty(Spd);
		logicDetail.setSndgPty(Spd);
		logicDetail.setAcqrr(acqr);
		logicDetail.setAcqrr(acqr);
		logicDetail.setIssr(Issr);
		logicDetail.setRcptPty(RcptPty);
		
		
		
		
		
		////List <LogclFileDetails> lfd = new ArrayList<LogclFileDetails>();
		//lfd.setLogclHdr(logicDetail);
		//lfd.add(logicDetail);
		
		ArrayList<RFPBatchFile> list=new ArrayList<RFPBatchFile>();  
	    //list.addlogicDetail)
		
		
		
		
		
		

		
		
		


		
		
		
		
		
		Trailerdetails tdmg = new Trailerdetails();
		BigDecimal a = new BigDecimal("0.03");
		tdmg.setLogclFileCnt(a);
		
		wmg.setHdr(hdmg);
	//	wmg.getLogclFile(list);
		wmg.setTrlr(tdmg);
		
		
	//	Spd
		
		String msg = xmlTest.getXML(wmg);
		System.out.println(msg);
	}

//	private static XMLGregorianCalendar toXMLGregorianCalendar(Date today) {
//		// TODO Auto-generated method stub
//		return null;
//	}
}

