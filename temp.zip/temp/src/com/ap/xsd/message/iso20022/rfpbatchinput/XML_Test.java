package com.ap.xsd.message.iso20022.rfpbatchinput;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

//import com.xml.util.Answer;

import iso.std.iso._20022.tech.xsd.head_001_001.ContactDetails2;
import iso.std.iso._20022.tech.xsd.head_001_001.CopyDuplicate1Code;
import iso.std.iso._20022.tech.xs.rain_002_001.AcceptorAuthorisationRequestV07;
import iso.std.iso._20022.tech.xs.rain_002_001.AcceptorAuthorisationRequest7;
import iso.std.iso._20022.tech.xs.rain_002_001.Acquirer4;
import iso.std.iso._20022.tech.xs.rain_002_001.CardPaymentEnvironment68;
import iso.std.iso._20022.tech.xs.rain_002_001.CardPaymentToken4;
import iso.std.iso._20022.tech.xs.rain_002_001.Cardholder13;
import iso.std.iso._20022.tech.xs.rain_002_001.CommunicationAddress9;
import iso.std.iso._20022.tech.xs.rain_002_001.CustomerDevice1;
import iso.std.iso._20022.tech.xs.rain_002_001.DeviceOSEnum;
import iso.std.iso._20022.tech.xs.rain_002_001.DeviceTypeEnum;
import iso.std.iso._20022.tech.xs.rain_002_001.Document;
import iso.std.iso._20022.tech.xs.rain_002_001.GenericIdentification32;
import iso.std.iso._20022.tech.xs.rain_002_001.GenericIdentification4;
import iso.std.iso._20022.tech.xs.rain_002_001.GenericIdentification53;
import iso.std.iso._20022.tech.xs.rain_002_001.GenericIdentification76;
import iso.std.iso._20022.tech.xs.rain_002_001.GenericIdentification94;
import iso.std.iso._20022.tech.xs.rain_002_001.Header35;
import iso.std.iso._20022.tech.xs.rain_002_001.IBPBrowserInfoType;
import iso.std.iso._20022.tech.xs.rain_002_001.IBPDeviceInfoType;
import iso.std.iso._20022.tech.xs.rain_002_001.IBPGenericIdentification53;
import iso.std.iso._20022.tech.xs.rain_002_001.IBPName;
import iso.std.iso._20022.tech.xs.rain_002_001.IBPTransactionSymmary;
import iso.std.iso._20022.tech.xs.rain_002_001.LocationCategory1Code;
import iso.std.iso._20022.tech.xs.rain_002_001.LocationCategory3Code;
import iso.std.iso._20022.tech.xs.rain_002_001.MessageFunction14Code;
import iso.std.iso._20022.tech.xs.rain_002_001.NamePrefix1Choice;
import iso.std.iso._20022.tech.xs.rain_002_001.NamePrefix1Code;
import iso.std.iso._20022.tech.xs.rain_002_001.NetworkParameters4;
import iso.std.iso._20022.tech.xs.rain_002_001.NetworkParameters5;
import iso.std.iso._20022.tech.xs.rain_002_001.NetworkType1Code;
import iso.std.iso._20022.tech.xs.rain_002_001.Organisation32;
import iso.std.iso._20022.tech.xs.rain_002_001.PartyType3Code;
import iso.std.iso._20022.tech.xs.rain_002_001.PartyType4Code;
import iso.std.iso._20022.tech.xs.rain_002_001.PaymentCard28;
import iso.std.iso._20022.tech.xs.rain_002_001.PersonIdentification15;
import iso.std.iso._20022.tech.xs.rain_002_001.PersonalDataType;
import iso.std.iso._20022.tech.xs.rain_002_001.PointOfInteraction8;
import iso.std.iso._20022.tech.xs.rain_002_001.PointOfInteractionComponent8;
import iso.std.iso._20022.tech.xs.rain_002_001.PostalAddress22;
import iso.std.iso._20022.tech.xs.rain_002_001.SupplementaryData1;
import iso.std.iso._20022.tech.xs.rain_002_001.Traceability5;
import iso.std.iso._20022.tech.xs.rain_002_001.YNtypefieldsCode;
import iso.std.iso._20022.tech.xsd.head_001_001.AddressType2Code;
import iso.std.iso._20022.tech.xsd.head_001_001.BusinessApplicationHeaderV01;
import iso.std.iso._20022.tech.xsd.head_001_001.DateAndPlaceOfBirth;
import iso.std.iso._20022.tech.xsd.head_001_001.OrganisationIdentification7;
import iso.std.iso._20022.tech.xsd.head_001_001.Party10Choice;
import iso.std.iso._20022.tech.xsd.head_001_001.Party9Choice;
import iso.std.iso._20022.tech.xsd.head_001_001.PartyIdentification42;
import iso.std.iso._20022.tech.xsd.head_001_001.PersonIdentification5;
import iso.std.iso._20022.tech.xsd.head_001_001.PostalAddress6;

/**
 * @author bharat
 * 
 */
public class XML_Test {

	private static JAXBContext context;

	public static final ThreadLocal<Marshaller> threadLocalMarshaller = new ThreadLocal<Marshaller>();

	public boolean init() {
		boolean ret = true;
		try {
			context = JAXBContext.newInstance(RFPBatchFile.class);
		} catch (JAXBException ex) {
			// LOGGER.error("Error while creating JAXB context", ex);
			ret = false;
		}
		return ret;
	}

	public String getXML(final RFPBatchFile workItemMesg) throws JAXBException {

		Marshaller marshaller = threadLocalMarshaller.get();

		if (marshaller == null) {
			marshaller = context.createMarshaller();

			threadLocalMarshaller.set(marshaller);
		}

		StringWriter sw = new StringWriter();

		marshaller.marshal(workItemMesg, sw);
		System.out.println(workItemMesg);
		System.out.println("==>" + sw.toString());

		return sw.toString();
		// return workItemMesg.toString().

		// marshaller.marshal(workItemMesg, new FileOutputStream("question.xml"));

	}

	public static void main(String args[]) throws JAXBException, DatatypeConfigurationException {
		XML_Test xmlTest = new XML_Test();
		xmlTest.init();

		RFPBatchFile objFPBatchFile = new RFPBatchFile();

		PartyDetails objPD = new PartyDetails();
		objPD.setId("Zapp");
		objPD.setTp(PartyTypeCode.SCHM);

		// PartyDetails Spd = new PartyDetails();
		// Spd.setId("000014");
		// Spd.setTp(PartyTypeCode.DSTR);
		//
		// PartyDetails acqr = new PartyDetails();
		// acqr.setId("009368");
		// acqr.setTp(PartyTypeCode.DSTR);
		//
		// PartyDetails Issr = new PartyDetails();
		// acqr.setId("012352");
		// acqr.setTp(PartyTypeCode.FINI);
		//
		// PartyDetails RcptPty = new PartyDetails();
		// RcptPty.setId("Zapp");
		// RcptPty.setTp(PartyTypeCode.SCHM);

		objPD.setId("000014");
		objPD.setTp(PartyTypeCode.DSTR);

		objPD.setId("009368");
		objPD.setTp(PartyTypeCode.DSTR);

		objPD.setId("012352");
		objPD.setTp(PartyTypeCode.FINI);

		objPD.setId("Zapp");
		objPD.setTp(PartyTypeCode.SCHM);

		GregorianCalendar gcal = new GregorianCalendar();

		GregorianCalendar c = new GregorianCalendar();
		c.setTime(new Date());
		XMLGregorianCalendar xmldate = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		Date date = xmldate.toGregorianCalendar().getTime();

//		HeaderDetails hdmg = new HeaderDetails();
//		hdmg.setFileRef("RTLR013rra");
//		hdmg.setFileTp("RFPInputFromDistributor");
//		hdmg.setRcptPty(objPD);
//		hdmg.setRcptPty(objPD);
//		hdmg.setSndgPty(Spd);
//		hdmg.setSndgPty(Spd);
//		hdmg.setFileBusDt(xmldate);

		HeaderDetails hdmg = new HeaderDetails();
		hdmg.setFileRef("RTLR013rra");
		hdmg.setFileTp("RFPInputFromDistributor");
		hdmg.setRcptPty(objPD);
		hdmg.setRcptPty(objPD);
		hdmg.setSndgPty(objPD);
		hdmg.setSndgPty(objPD);
		hdmg.setFileBusDt(xmldate);

//		LogicalHeaderDetails logicDetail = new LogicalHeaderDetails();
//		logicDetail.setLogclFileRef("RTLR013rra");
//		logicDetail.setMsgTp("RTLRespFromDist");
//		logicDetail.setSndgPty(Spd);
//		logicDetail.setSndgPty(Spd);
//		logicDetail.setAcqrr(acqr);
//		logicDetail.setAcqrr(acqr);
//		logicDetail.setIssr(Issr);
//		logicDetail.setRcptPty(RcptPty);



		ArrayList<RFPBatchFile> list = new ArrayList<RFPBatchFile>();

		// set the contact detail 2

		ContactDetails2 conDTwo = new ContactDetails2();
		conDTwo.setFaxNb("9910967473");
		conDTwo.setEmailAdr("BharatTest@gmail.com");
		conDTwo.setMobNb("4546788990");
		conDTwo.setNm("Bharat");
		conDTwo.setOthr("other");
		conDTwo.setPhneNb("786778909");

		PostalAddress6 PstlAdr = new PostalAddress6();
		PstlAdr.setAdrTp(AddressType2Code.BIZZ);
		PstlAdr.setDept("String");
		PstlAdr.setSubDept("String");
		PstlAdr.setStrtNm("String");
		PstlAdr.setBldgNb("String");
		PstlAdr.setTwnNm("String");
		PstlAdr.setCtrySubDvsn("String");
		PstlAdr.setCtry("US");
		// ArrayList<String> getAdrLineString = new ArrayList<String>();
		// PstlAdr.getAdrLine(getAdrLineString);

		OrganisationIdentification7 orgId7 = new OrganisationIdentification7();
		orgId7.setAnyBIC("String");

		DateAndPlaceOfBirth DaPB = new DateAndPlaceOfBirth();
		DaPB.setBirthDt(xmldate);
		DaPB.setPrvcOfBirth("PrvcOfBirth");
		DaPB.setCityOfBirth("CityOfBirth");
		DaPB.setCtryOfBirth("US");

		PersonIdentification5 PID5 = new PersonIdentification5();
		PID5.setDtAndPlcOfBirth(DaPB);

		Party10Choice Party10 = new Party10Choice();
		Party10.setOrgId(orgId7);
		Party10.setPrvtId(PID5);

		PartyIdentification42 PartyId42 = new PartyIdentification42();
		PartyId42.setNm("String");
		PartyId42.setPstlAdr(PstlAdr);
		PartyId42.setId(Party10);
		PartyId42.setPstlAdr(PstlAdr);
		PartyId42.setCtctDtls(conDTwo);

		Party9Choice Party9 = new Party9Choice();
		Party9.setOrgId(PartyId42);

		BusinessApplicationHeaderV01 BusAppHeader01 = new BusinessApplicationHeaderV01();

		BusAppHeader01.setCharSet("Charset");
		BusAppHeader01.setBizMsgIdr("RTLRespFromDist");
		BusAppHeader01.setFr(Party9);
		BusAppHeader01.setTo(Party9);
		BusAppHeader01.setBizMsgIdr("BizMsgIdr");
		BusAppHeader01.setBizMsgIdr("MsgDefIdr");
		BusAppHeader01.setBizSvc("BizSvc");
		BusAppHeader01.setCreDt(xmldate);
		BusAppHeader01.setCpyDplct(CopyDuplicate1Code.CODU);
		BusAppHeader01.setPssblDplct(false);
		BusAppHeader01.setPrty("Prty");
		// BusAppHeader01.setSgntr("setSgntr");

		ReqPayloadType ReqPayloadTP = new ReqPayloadType();
		ReqPayloadTP.setAppHdr(BusAppHeader01);
		// ----------------------------------------------------
		GenericIdentification53 GGenericIdentification53 = new GenericIdentification53();
		GGenericIdentification53.setId("000010SANAKHAN");
		GGenericIdentification53.setTp(PartyType3Code.ACCP);
		GGenericIdentification53.setIssr(PartyType4Code.TAXH);
		GGenericIdentification53.setCtry("US");
		GGenericIdentification53.setShrtNm("string");

		// ArrayList<NetworkParameters4> Nlist=new ArrayList<NetworkParameters4>();

		NetworkParameters4 NetworkParameter4 = new NetworkParameters4();
		NetworkParameter4.setNtwkTp(NetworkType1Code.PSTN);
		NetworkParameter4.setAdrVal("string");

		NetworkParameters5 NNetworkParameters5 = new NetworkParameters5();

		NNetworkParameters5.getAdr().add(NetworkParameter4);
		NNetworkParameters5.setUsrNm("string");
		byte[] buffer = { 71, 69, 69, 75, 83 };
		NNetworkParameters5.setAccsCd(buffer);
		// NNetworkParameters5. TBD

		GenericIdentification94 GGenericIdentification94 = new GenericIdentification94();
		GGenericIdentification94.setId("String");
		GGenericIdentification94.setTp(PartyType3Code.ACQR);
		GGenericIdentification94.setIssr(PartyType4Code.ACCP);
		GGenericIdentification94.setCtry("US");
		GGenericIdentification94.setShrtNm("string");
		GGenericIdentification94.setRmotAccs(NNetworkParameters5);

		GenericIdentification76 GGenericIdentification76 = new GenericIdentification76();
		GGenericIdentification76.setId("009368");
		GGenericIdentification76.setTp(PartyType3Code.ACQR);
		GGenericIdentification76.setIssr(PartyType4Code.CISS);
		GGenericIdentification76.setCtry("US");
		GGenericIdentification76.setShrtNm("string");

		Traceability5 TTraceability5 = new Traceability5();
		TTraceability5.setRlayId(GGenericIdentification76);
		TTraceability5.setPrtcolNm("string");
		TTraceability5.setPrtcolVrsn("string");
		TTraceability5.setTracDtTmIn(xmldate);
		TTraceability5.setTracDtTmOut(xmldate);

		Header35 HHeader35 = new Header35();
		HHeader35.setMsgFctn(MessageFunction14Code.OPIN);
		HHeader35.setPrtcolVrsn("001");
		HHeader35.setXchgId("001");
		HHeader35.setCreDtTm(xmldate);
		HHeader35.setInitgPty(GGenericIdentification53);
		HHeader35.setRcptPty(GGenericIdentification94);
		HHeader35.getTracblt().add(TTraceability5);

		GenericIdentification4 GGenericIdentification4 = new GenericIdentification4();
		GGenericIdentification4.setId("string");
		GGenericIdentification4.setIdTp("String");

		IBPGenericIdentification53 IIBPGenericIdentification53 = new IBPGenericIdentification53();
		IIBPGenericIdentification53.setId("009368");
		IIBPGenericIdentification53.setTp(PartyType3Code.ACQR);
		IIBPGenericIdentification53.setIssr(PartyType4Code.CISS);
		IIBPGenericIdentification53.setCtry("US");
		IIBPGenericIdentification53.setShrtNm("string");

		Acquirer4 AAcquirer4 = new Acquirer4();
		AAcquirer4.setId(IIBPGenericIdentification53);

		GenericIdentification32 GGenericIdentification32 = new GenericIdentification32();
		GGenericIdentification32.setId("00CI74GRS");
		GGenericIdentification32.setTp(PartyType3Code.MERC);
		GGenericIdentification32.setIssr(PartyType4Code.CISS);
		GGenericIdentification32.setShrtNm("string");

		PostalAddress22 PPostalAddress22 = new PostalAddress22();
		PPostalAddress22.setShppgAdrId("string");
		PPostalAddress22.setFIRegd(false);
		PPostalAddress22.setThrdPtyAdrInd(false);
		// TBG//PPostalAddress22.setAdrTp(AddressType2Code.BIZZ);
		PPostalAddress22.setDept("string");
		PPostalAddress22.setSubDept("string");
		PPostalAddress22.getAdrLine().add("String");
		PPostalAddress22.setStrtNm("string");
		PPostalAddress22.setBldgNb("string");
		PPostalAddress22.setPstCd("string");
		PPostalAddress22.setTwnNm("string");
		PPostalAddress22.getCtrySubDvsn().add("string");
		PPostalAddress22.setCtryCd("US");

		CommunicationAddress9 CCommunicationAddress9 = new CommunicationAddress9();
		CCommunicationAddress9.setPstlAdr(PPostalAddress22);
		CCommunicationAddress9.setEmail("string");
		CCommunicationAddress9.setURLAdr("string");
		CCommunicationAddress9.setPhne("string");
		CCommunicationAddress9.setAddtlCtctInf("string");

		Organisation32 OOrganisation32 = new Organisation32();
		OOrganisation32.setId(GGenericIdentification32);
		OOrganisation32.setCmonNm("stringstringstringstrings");
		OOrganisation32.setLctnCtgy(LocationCategory1Code.HOME);
		OOrganisation32.setLctnAndCtct(CCommunicationAddress9);
		OOrganisation32.setSchmeData("string");

		PersonIdentification15 PPersonIdentification15 = new PersonIdentification15();
		PPersonIdentification15.setDrvrLicNb("String");
		PPersonIdentification15.setDrvrLicLctn("string");
		PPersonIdentification15.setDrvrId("String");
		PPersonIdentification15.setCstmrNb("String");
		PPersonIdentification15.setAlnRegnNb("string");
		PPersonIdentification15.setPsptNb("string");
		PPersonIdentification15.setTaxIdNb("string");
		PPersonIdentification15.setIdntyCardNb("string");
		PPersonIdentification15.setMplyrIdNb("string");
		PPersonIdentification15.setMplyeeIdNb("string");
		PPersonIdentification15.setJobNb("string");
		PPersonIdentification15.setDept("string");
		PPersonIdentification15.setEmailAdr("string");
		PPersonIdentification15.getOthr().add(GGenericIdentification4);

		NamePrefix1Choice NNamePrefix1Choice = new NamePrefix1Choice();
		NNamePrefix1Choice.setCd(NamePrefix1Code.DOCT);
		NNamePrefix1Choice.setXtndedNmPrfx("XNP");

		IBPName IIBPName = new IBPName();
		IIBPName.setNmPrfx(NNamePrefix1Choice);
		IIBPName.setGvnNm("string");
		IIBPName.setMddlNm("string");
		IIBPName.setLstNm("string");

		PersonalDataType PPersonalDataType = new PersonalDataType();
		PPersonalDataType.setMobNb("string");

		Cardholder13 CCardholder13 = new Cardholder13();

		CCardholder13.setId(PPersonIdentification15);
		CCardholder13.setNm(IIBPName);
		CCardholder13.setLang("string");
		CCardholder13.setBllgAdr(PPostalAddress22);
		CCardholder13.setShppgAdr(PPostalAddress22);
		CCardholder13.setPrsnlData(PPersonalDataType);
		CCardholder13.getPrfrnc().add(YNtypefieldsCode.MOBV);

		IBPDeviceInfoType IIBPDeviceInfoType = new IBPDeviceInfoType();
		IIBPDeviceInfoType.setDeviceType(DeviceTypeEnum.TBLT);
		IIBPDeviceInfoType.setIPAddress("127.0.0.123");
		IIBPDeviceInfoType.setDeviceOS(DeviceOSEnum.OTHR);

		IBPBrowserInfoType IIBPBrowserInfoType = new IBPBrowserInfoType();
		IIBPBrowserInfoType.setUserAgent("userAgent");
		IIBPBrowserInfoType.setActiveHeaders("ActiveHeaders");
		IIBPBrowserInfoType.setTimeZone("TimeZone");
		IIBPBrowserInfoType.setScreen("Screen");

		PointOfInteractionComponent8 PPointOfInteractionComponent8 = new PointOfInteractionComponent8();

		PaymentCard28 PPaymentCard28 = new PaymentCard28();

		PointOfInteraction8 PPointOfInteraction8 = new PointOfInteraction8();
		PPointOfInteraction8.setId(GGenericIdentification53);
		PPointOfInteraction8.setSysNm("String");
		PPointOfInteraction8.setGrpId("String");
		PPointOfInteraction8.setBrowserInfo(IIBPBrowserInfoType);
		PPointOfInteraction8.setTmZone("TmZone");
		PPointOfInteraction8.setTermnlIntgtn(LocationCategory3Code.INDR);
		PPointOfInteraction8.setMerchantRtnStrng("MerchantRtnStrng");
		PPointOfInteraction8.getCmpnt().add(PPointOfInteractionComponent8);

		CustomerDevice1 CCustomerDevice1 = new CustomerDevice1();

		CardPaymentToken4 CCardPaymentToken4 = new CardPaymentToken4();

		CardPaymentEnvironment68 CCardPaymentEnvironment68 = new CardPaymentEnvironment68();

		CCardPaymentEnvironment68.setAcqrr(AAcquirer4);
		CCardPaymentEnvironment68.setMrchnt(OOrganisation32);
		CCardPaymentEnvironment68.setCstmrFinInst(AAcquirer4);
		CCardPaymentEnvironment68.setCustomer(CCardholder13);
		CCardPaymentEnvironment68.setPOI(PPointOfInteraction8);
		CCardPaymentEnvironment68.setCard(PPaymentCard28);
		CCardPaymentEnvironment68.setWllt(CCustomerDevice1);
		CCardPaymentEnvironment68.setPmtTkn(CCardPaymentToken4);

		IBPTransactionSymmary IIBPTransactionSymmary = new IBPTransactionSymmary();

		SupplementaryData1 SSupplementaryData1 = new SupplementaryData1();

		AcceptorAuthorisationRequest7 AAcceptorAuthorisationRequest7 = new AcceptorAuthorisationRequest7();
		AAcceptorAuthorisationRequest7.setEnvt(CCardPaymentEnvironment68);
		AAcceptorAuthorisationRequest7.setTx(IIBPTransactionSymmary);
		AAcceptorAuthorisationRequest7.getSplmtryData().add(SSupplementaryData1);

		AcceptorAuthorisationRequestV07 AAcceptorAuthorisationRequestV07 = new AcceptorAuthorisationRequestV07();

		AAcceptorAuthorisationRequestV07.setHdr(HHeader35);
		AAcceptorAuthorisationRequestV07.setPrsntmntRes(AAcceptorAuthorisationRequest7);

		Document DDocument = new Document();
		DDocument.setPrsntmnt(AAcceptorAuthorisationRequestV07);

		ResPayloadType ResPayloadTP = new ResPayloadType();
		ResPayloadTP.setAppHdr(BusAppHeader01);
		ResPayloadTP.setDocument(DDocument);

		ReqMessageType ReqMessageTP = new ReqMessageType();
		ReqMessageTP.setMsgRef("MsgRef");
		ReqMessageTP.setReqPayload(ReqPayloadTP);

		ResMessageType ResMessageTypee = new ResMessageType();
		ResMessageTypee.setMsgRef("MsgRef");
		ResMessageTypee.setRspnPayload(ResPayloadTP);

		// ArrayList<ReqMessageType> ReqMessageTPlist = new ArrayList<ReqMessageType>();
		// ReqMessageTPlist.add(ReqPayloadTP);
		
		LogicalHeaderDetails logicDetail = new LogicalHeaderDetails();
		logicDetail.setLogclFileRef("RTLR013rra");
		logicDetail.setMsgTp("RTLRespFromDist");
		logicDetail.setSndgPty(objPD);
		logicDetail.setSndgPty(objPD);
		logicDetail.setAcqrr(objPD);
		logicDetail.setAcqrr(objPD);
		logicDetail.setIssr(objPD);
		logicDetail.setRcptPty(objPD);

		LogclFileDetails lfd = new LogclFileDetails();

		lfd.setLogclHdr(logicDetail);
		

		MessageDetail MsgDetail = new MessageDetail();
		// MsgDetail.getReqMessage ().add(ReqMessageTP);
		MsgDetail.getRspnMessage().add(ResMessageTypee);

		LogclFileDetails LogclFileDels = new LogclFileDetails();
		LogclFileDels.setMessage(MsgDetail);

		///////////////////////////// Response Payloads/////////

		Trailerdetails tdmg = new Trailerdetails();
		BigDecimal a = new BigDecimal("0.03");
		tdmg.setLogclFileCnt(a);

		objFPBatchFile.setHdr(hdmg);
//		lfd.setMessage(MsgDetail);
//		lfd.setLogclTrlr(value);
		 objFPBatchFile.getLogclFile().add(lfd);

		objFPBatchFile.getLogclFile().add(LogclFileDels);
		// objFPBatchFile.getLogclFile().add(MsgDetail);

		// System.out.println(objFPBatchFile.getLogclFile().add(LogclFileDels));

		objFPBatchFile.setTrlr(tdmg);

		// marshaller.marshal(que, new FileOutputStream("question.xml"));

		// marshaller.marshal(workItemMesg, sw);
		String msg = xmlTest.getXML(objFPBatchFile);
		System.out.println(msg);
		// objFPBatchFile

		//// GM
		boolean initOK = XMLMarshaller.init();
		try {
			@SuppressWarnings("unused")
			String xml = XMLMarshaller.getXML(objFPBatchFile);
			System.out.println("xml==>\n" + xml);
		} catch (JAXBException e) {

			e.printStackTrace();
		}
	}

}
