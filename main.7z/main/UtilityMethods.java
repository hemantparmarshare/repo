package com.billpay.main;
import java.util.UUID;

public class UtilityMethods {

	public static String staticgetUniueNum() {

		UUID rndNumber = UUID.randomUUID();

		String rndNumber1 = "Bharat" + rndNumber.toString();
		return rndNumber1;
	}

}
