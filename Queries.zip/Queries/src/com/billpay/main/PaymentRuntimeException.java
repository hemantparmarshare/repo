package com.billpay.main;


/**
 * Handles custom  Runtime Exceptions (Server side)
 */
public class PaymentRuntimeException extends RuntimeException {
    private static final long serialVersionUID = -3156470218445547841L;
    /**
    
   
     * @param   message the detail message.
     * @param   cause the cause
     */
    public PaymentRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
    
     * @param   message the detail message.
     */
    public PaymentRuntimeException(String message){
        super(message);
    }
}
