package com.billpay.main;
import java.io.InputStream;
import java.io.StringReader;
import java.util.UUID;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;

public class UtilityMethods {

	public static String staticgetUniueNum() {

		UUID rndNumber = UUID.randomUUID();

		String rndNumber1 = "Bharat" + rndNumber.toString();
		return rndNumber1;
	}
	
	
	
	
}
