package com.billpay.main;

public interface CommonConstants {
	public String DB_DRIVER = "jdbc:oracle:thin:@10.105.48.50:1522/APOPIT.test.vocalink.co.uk";
	public String DB_USERNAME = "ST22_APMDM";
	public String DB_PASSWORD = "PASSWORD123-";
	public String CONNECTED_DATABASE_SUCCESSFULLY = "Connected database successfully";
	public String ENVIRONMENT = "environment";
	public String ISSUE_IN_LOADING_ENVIRONMENT_VARIABLE = "Issue in loading enviornment variable";
	public String ERROR_IN_CONNECTING_TO_SAFESTORE_DB = "Error in connecting to safestore DB";
	public String STR = "{}";
	public String ERROR_IN_EXECUTING_THE_QUERY = "Error in executing the query:";

}
