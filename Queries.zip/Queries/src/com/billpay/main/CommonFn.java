package com.billpay.main;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class CommonFn {

	public static String getCurrentDate() {
		String pattern = "EEEEE MMMMM yyyy HH:mm:ss.SSSZ";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, new Locale("en", "US"));
		String date = simpleDateFormat.format(new Date());
		return date;

	}

	public static String getFileRef() {
		Random rand = new Random();
		int n = rand.nextInt(5000);
		String fileRef = "Bha" + n;
		return fileRef;
	}

}
