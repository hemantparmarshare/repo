package com.billpay.main;

/**
 * This Enum is used to enable readability of SQL queries and their manipulation
 * 
 * 
 */


	
public enum PaymentFetchQueries {
	
	 

	PAYMENT_DATA("SELECT * FROM (SELECT \r\n" + 
			"TMM.MERCHANT_IDENTIFICATION,\r\n" + 
			"LPAD(TMM.DISTRIBUTOR_ID,6,0) AS DISTRIBUTORID,\r\n" + 
			"LPAD(TMA.ACQUIRER_ID,6,0) AS ACQUIRER_ID,\r\n" + 
			"LPAD(TMMM.FI_ID,6,0) AS FIID,\r\n" + 
			"TMMM.MANDATE_IDENTIFIER,\r\n" + 
			"TMMM.MANDATE_LINK_RETRIEVAL_ID,\r\n" + 
			"TMMM.BILLER_ACCOUNT_IDENTIFIER\r\n" + 
			"FROM \r\n" + 
			"T_MD_MANDATE_MERCHANT TMMM,\r\n" + 
			"T_MD_MERCHANT TMM,\r\n" + 
			"T_MD_ACQUIRER TMA\r\n" + 
			"WHERE\r\n" + 
			"TMMM.MERCHANT_ID = TMM.MERCHANT_ID\r\n" + 
			"AND\r\n" + 
			"TMM.DISTRIBUTOR_ID = TMA.DISTRIBUTOR_ID\r\n" + 
			"AND\r\n" + 
			"TMMM.MANDATE_STATUS_CODE NOT IN('LINKED','DELETED')\r\n" + 
			"AND \r\n" + 
			"TMM.DISTRIBUTOR_ID = '000104'\r\n" + 
			"ORDER BY TMMM.FI_ID)"),
	
	//TOTAL_FI("select distinct (FI_ID) AS TOTALFI from t_md_mandate_merchant");
	

	TOTAL_FI("SELECT DISTINCT(Count(FI_ID)) As TOTALFI  FROM t_md_mandate_merchant");

	

//SELECT DISTINCT CustomerGender, Count(*) as Occurs FROM Customer GROUP BY CustomerGender;

	
	
	private String sql;

    /**
     * Constructor for fetch queries DBQuery manager to initialize the object with a db sql query
     */
    PaymentFetchQueries(String sql) {
        this.sql = sql;
    }

    /**
     * Getter method to return the sql query
     */

    public String getSQL() {
        return sql;
    } 
}