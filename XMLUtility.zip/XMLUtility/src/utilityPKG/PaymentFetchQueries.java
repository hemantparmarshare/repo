package utilityPKG;

/**
 * This Enum is used to enable readability of SQL queries and their manipulation
 */
public enum PaymentFetchQueries {
	

	PAYMENT_DATA("select * from T_MD_MANDATE_MERCHANT\r\n" + 
			"where MANDATE_STATUS_CODE not IN('LINKED','DELETED')"); 
	
	//PAYMENT_DATA("select * from products"); 
	

    private String sql;

    /**
     * Constructor for fetch queries DBQuery manager to initialize the object with a db sql query
     */
    PaymentFetchQueries(String sql) {
        this.sql = sql;
    }

    /**
     * Getter method to return the sql query
     */

    public String getSQL() {
        return sql;
    } 
}