package utilityPKG;

import java.sql.*;

/**
 * Implements methods defined in dao(database interaction)
 */
public class DAOImpl {

	/**
	 
	 * 
	 * @param SQLQuery The sql query to be exceuted.
	 * @return ResultSet
	 * @throws ClassNotFoundException
	 * @throws SQLException           The sql errors and exception.
	 */
	public ResultSet fetchPaymentData(String SQLQuery) throws PaymentRuntimeException, ClassNotFoundException {

		ResultSet resultSet = null;

		try {
			// step1 load the driver class
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// step2 create the connection object
			Connection con = DriverManager.getConnection(CommonConstants.DB_DRIVER, CommonConstants.DB_USERNAME,
					CommonConstants.DB_PASSWORD);

			// step3 create the statement object
			Statement stmt = con.createStatement();
			resultSet = stmt.executeQuery(SQLQuery);
		} catch (SQLException ex) {
			StringBuilder builder = new StringBuilder();
			builder.append(CommonConstants.ERROR_IN_EXECUTING_THE_QUERY).append(CommonConstants.STR);
			throw new PaymentRuntimeException(builder.toString(), ex);
		}
		return resultSet;
	}
}